package com.example.projectuts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.projectuts.content.CartItem;
import com.example.projectuts.content.CartSingleton;
import com.example.projectuts.content.Drink;

import java.util.ArrayList;

public class DetailDrinkActivity extends AppCompatActivity {
    Drink drink;
    ImageView image;
    TextView name, price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_drink);

        image=((ImageView)findViewById(R.id.itemImage));
        name= ((TextView)findViewById(R.id.itemName));
        price= ((TextView)findViewById(R.id.detailPrice));
        if(image==null||price==null||name==null) {
            Log.d("Something is ", "null");
            return;
        }
        getData();
        setData();
    }
    private void getData(){
        if(getIntent().hasExtra("index")){
            int index=getIntent().getIntExtra("index",-1);
            drink = Drink.getDrinks().get(index);
        }
        else{
            Intent i = new Intent(this,DrinkActivity.class);
            this.startActivity(i);
        }
    }
    private void setData(){
        String pricetxt = "Rp. "+drink.price;
        String itemName = drink.name;
        image.setImageResource(drink.picture);
        name.setText(itemName);
        price.setText(pricetxt);
    }

    public void setOrder(View view) {
        ArrayList<CartItem> carts = CartSingleton.getCart();
        int index = CartSingleton.getIndex(drink);
        String input = ((EditText)findViewById(R.id.quantity)).getText().toString();
        if(index==-1){
            carts.add(new CartItem(drink, Integer.parseInt(input)));
        }else{
            carts.get(index).qty += Integer.parseInt(input);
        }
        finish();
    }
    public void gotoMyOrder(View v){
        MainActivity.staticToOrder(this);
    }
}