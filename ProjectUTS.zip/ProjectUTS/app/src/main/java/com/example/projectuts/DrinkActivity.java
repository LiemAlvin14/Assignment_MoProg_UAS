package com.example.projectuts;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.projectuts.content.Drink;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DrinkActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<Drink> drinks;
    int pictures[]={R.drawable.air_putih, R.drawable.jus_apel, R.drawable.jus_mangga, R.drawable.jus_alpukat};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);
        drinks=Drink.getDrinks();
        recyclerView = findViewById(R.id.drinkRecycler);
        if(drinks.size()<pictures.length){
            Log.d("Initializing", "Drinks");
            String names[]=getResources().getStringArray(R.array.drinks);
            int price[]=getResources().getIntArray(R.array.drinks_price);
            for(int i = drinks.size(); i<names.length; i++){
                Drink d = new Drink(names[i], price[i], pictures[i]);
                drinks.add(d);
            }
        }
        String size = ""+Drink.getDrinks().size();
        Log.d("size",size);
        DrinkAdapter drinkAdapter = new DrinkAdapter(this);
        recyclerView.setAdapter(drinkAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    public void gotoMyOrder(View view){
        MainActivity.staticToOrder(this);
    }
}