package com.example.projectuts;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectuts.content.Drink;

import java.util.ArrayList;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.DViewHolder> {
    Context context;
    ArrayList<Drink> drinks;
    public DrinkAdapter(Context c){
        this.context=c;
        this.drinks=Drink.getDrinks();
    }

    @NonNull
    @Override
    public DViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater li = LayoutInflater.from(context);
        View view=li.inflate(R.layout.recycler_format, parent, false);

        return new DViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DViewHolder holder, final int position) {
        holder.name.setText(drinks.get(position).name);
        holder.price.setText(new String("Rp. "+drinks.get(position).price));
        holder.itemImage.setImageResource(drinks.get(position).picture);

        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, DetailDrinkActivity.class);
                i.putExtra("index", position);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return Drink.getDrinks().size();
}

    public class DViewHolder extends RecyclerView.ViewHolder {
        TextView name, price;
        ImageView itemImage;
        ConstraintLayout layout;
        public DViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.item_name);
            price=itemView.findViewById(R.id.price_txt);
            itemImage=itemView.findViewById(R.id.item_picture);
            this.layout=itemView.findViewById(R.id.itemLayout);
        }
    }
}
