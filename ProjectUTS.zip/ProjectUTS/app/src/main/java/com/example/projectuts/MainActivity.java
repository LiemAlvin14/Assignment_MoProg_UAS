package com.example.projectuts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.location.Address;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void goToDrink(View view) {
        Intent i = new Intent(this, DrinkActivity.class);
        startActivity(i);
    }
    public void gotoMyOrder(View view){
        staticToOrder(this);
    }
    public void goToMaps(View view){
        Intent i = new Intent(this, AddressActivity.class);
        startActivity(i);
    }
    public static void staticToOrder(AppCompatActivity ref){
        Intent intent = new Intent(ref, MyOrderActivity.class);
        ref.startActivity(intent);
    }
}