package com.example.projectuts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import com.example.projectuts.content.CartSingleton;

public class MyOrderActivity extends AppCompatActivity {
    RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order);
        rv=findViewById(R.id.cartRecycler);
        OrderAdapter oa = new OrderAdapter(this, OrderAdapter.MY_ORDER);
        rv.setAdapter(oa);
        rv.setLayoutManager(new LinearLayoutManager(this));
        Log.d("Size of order", ""+CartSingleton.getCart().size());
        ((TextView)findViewById(R.id.total_txt)).setText("Total: Rp. "+CartSingleton.getTotal());
    }

    public void payNow(View view) {
        Intent i = new Intent(this,PayNowActivity.class);
        startActivity(i);
    }
}