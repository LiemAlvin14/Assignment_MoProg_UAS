package com.example.projectuts;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectuts.content.CartItem;
import com.example.projectuts.content.CartSingleton;
import com.example.projectuts.content.Drink;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OViewHolder> {
    Context context;
    ArrayList<CartItem> list;
    public final static int PAY_NOW=1, MY_ORDER=2;
    int activity;
    public OrderAdapter(Context c, int activity){
        this.context=c;
        this.activity=activity;
        switch (activity){
            case MY_ORDER:{
                this.list= CartSingleton.getCart();
                break;
            }
            case PAY_NOW:{
                this.list=new ArrayList<>();
                for(CartItem item : CartSingleton.getCart()){
                    CartItem input = new CartItem(item.drink.clone(), item.qty);
                    this.list.add(input);
                }
                break;
            }
        }
    }

    @NonNull
    @Override
    public OViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater li = LayoutInflater.from(context);
        View view=li.inflate(R.layout.cart_format, parent, false);

        return new OViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OViewHolder holder, final int position) {
        Drink curr = list.get(position).drink;
        String price = "Rp. "+ curr.price;

        holder.name.setText(curr.name);
        holder.price.setText(price);
        holder.itemImage.setImageResource(curr.picture);
        holder.qty.setText("Qty: "+list.get(position).qty);
        switch (activity){
            case MY_ORDER:{
                holder.delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        CartSingleton.getCart().remove(position);
                        notifyDataSetChanged();
                    }
                });
                break;
            }
            case PAY_NOW:{
                holder.delete.setVisibility(View.GONE);
                break;
            }
        }
    }

    @Override
    public int getItemCount() {
            return list==null?0:list.size();
}

    public class OViewHolder extends RecyclerView.ViewHolder {
        TextView name, price, qty;
        ImageView itemImage;
        Button delete;
        View view;
        public OViewHolder(@NonNull View itemView) {
            super(itemView);
            this.view = itemView;
            name=itemView.findViewById(R.id.item_name);
            price=itemView.findViewById(R.id.price_txt);
            itemImage=itemView.findViewById(R.id.item_picture);
            qty=itemView.findViewById(R.id.qty_txt);
            this.delete=itemView.findViewById(R.id.deleteBtn);
        }
    }
}
