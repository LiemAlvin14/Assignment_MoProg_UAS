package com.example.projectuts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.projectuts.content.CartSingleton;

public class PayNowActivity extends AppCompatActivity {
    RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_now);
        ((TextView)findViewById(R.id.total_txt)).setText("Total: Rp. "+CartSingleton.getTotal());
        rv=findViewById(R.id.cartRecycler);
        OrderAdapter oa = new OrderAdapter(this, OrderAdapter.PAY_NOW);
        rv.setAdapter(oa);
        rv.setLayoutManager(new LinearLayoutManager(this));

        CartSingleton.payNow();
    }

    public void toMenu(View view) {

        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}