package com.example.projectuts.content;

import android.location.Address;

public class AddressData {
    private Address address;
    private String location;
    private boolean isSet = false;
    public AddressData(){
        this.address = null;
        location=new String();
    }

    public void setAddress(Address a, String loc){
        this.address = a;
        this.location = loc;
        this.isSet=true;
    }
    public Address getAddress(){
        return address;
    }
    public String getLocation(){
        return location;
    }
    public boolean isSet(){ return isSet;}
    private static AddressData data=null;
    public static AddressData getInstance(){
        if(data==null){
            data =new AddressData();
        }
        return data;
    }
}
