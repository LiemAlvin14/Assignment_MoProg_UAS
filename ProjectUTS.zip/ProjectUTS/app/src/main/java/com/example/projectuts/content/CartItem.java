package com.example.projectuts.content;

public class CartItem {
    public Drink drink;
    public int qty;
    public CartItem(Drink drink, int qty){
        this.drink=drink;
        this.qty=qty;
    }
}
