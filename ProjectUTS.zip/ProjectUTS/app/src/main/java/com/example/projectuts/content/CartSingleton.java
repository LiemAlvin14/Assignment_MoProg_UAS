package com.example.projectuts.content;

import com.example.projectuts.content.Drink;

import java.util.ArrayList;

public class CartSingleton {
    private static ArrayList<CartItem> cart;
    public static ArrayList<CartItem> getCart(){
        if(cart==null)cart=new ArrayList<>();
        return cart;
    }

    public static int getIndex(Drink drink) {
        for (int i = 0; i<cart.size(); i++) {
            CartItem item = cart.get(i);
            if(item.drink.equals(drink))return i;
        }
        return -1;
    }

    public static void payNow() {
        for(CartItem i : cart){
            cart.remove(i);
        }
    }

    public static int getTotal() {
        int total=0;
        for(CartItem i: cart)total+=(i.drink.price*i.qty);
        return total;
    }
}
