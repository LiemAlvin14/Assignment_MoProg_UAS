package com.example.projectuts.content;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class Drink {
    public String name;
    public int price;
    public int picture;
    private static ArrayList<Drink> drinks=null;
    public static ArrayList<Drink> getDrinks(){
        if(drinks==null){
            drinks=new ArrayList<>();
        }
        return drinks;
    }
    public Drink(String name, int price, int pic){
        this.name=name;
        this.price=price;
        this.picture=pic;
    }
    public Drink clone(){
        Drink d = new Drink(this.name,this.price, this.picture);
        return d;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if(!(obj instanceof Drink))return false;
        Drink o = (Drink)obj;
        if(name.equals(o.name) && price==o.price && picture==o.picture)return true;
        return false;
    }
}
